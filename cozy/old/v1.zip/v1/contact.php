<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="scripts/jqtransform/jqtransform.css" type="text/css" media="all" />
<link rel="stylesheet" href="scripts/main.css" type="text/css" media="all" />
<link href="scripts/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="scripts/SpryValidationTextarea.css" rel="stylesheet" type="text/css" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
<script src="scripts/SpryValidationTextField.js" type="text/javascript"></script>
<script src="scripts/SpryValidationTextarea.js" type="text/javascript"></script>
<script type="text/javascript" src="scripts/jqtransform/jquery.jqtransform.js" ></script>
<script type="text/javascript">
$(function() {
    //find all form with class jqtransform and apply the plugin
    $("form.jqtransform").jqTransform();
});
</script>
<title>Cozy Lil' Cottage Contact Us</title>
</head>
<body>
<table width="600px" height="485px" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td width="579px" height="453px" align="center" valign="middle" style="background: url(images/paper_bg_con.png) center no-repeat;">
        <table width="540px" height="400x" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center" valign="middle">
                <table width="100%" border="0" cellspacing="5" cellpadding="0">
                  <tr>
                    <td class="banner" align="center">Contact Us</td>
                  </tr>
                  <?php if (!isset($_SERVER['REQUEST_METHOD']) or $_SERVER['REQUEST_METHOD'] != "POST") { ?>
                  <tr>
                    <td align="center">If you have any questions or comments, you may contact us using the form below or by e-mailing us at <a href="mailto:jen@cozylilcottage.com">jen@cozylilcottage.com</a>.</td>
                  </tr>
                  <?php } ?>
                  <tr>
                    <td align="center" valign="middle">
                        <table width="520px" height="300px" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td align="center" valign="middle">
                                 <?php function showMailForm() { ?>
                                 <form action="contact.php" method="post" class="jqtransform">
                                 <table width="500px" border="0" cellspacing="0" cellpadding="0" align="center">
                                  <tr>
                                    <td height="15"></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><strong>Name: </strong></td>
                                    <td><span id="sprytextfield1">
                                        <input name="name" type="text" id="name" size="30" value="<?php echo $_POST['name']; ?>" />
                                        <img src="images/ok.png" title="Valid" alt="Valid" class="validMsg" border="0"/>
                                        <span class="textfieldRequiredMsg"><img src="images/wrong.png" /></span>    
                                    </span></td>
                                  </tr>
                                  <tr>
                                    <td height="15"></td>
                                  </tr>
                                  <tr>
                                    <td align="left"><strong>E-Mail or Phone: </strong></td>
                                    <td><span id="sprytextfield2">
                                        <input name="email" type="text" id="email" size="30" value="<?php echo $_POST['email']; ?>" />
                                        <img src="images/ok.png" title="Valid" alt="Valid" class="validMsg" border="0"/>
                                        <span class="textfieldRequiredMsg"><img src="images/wrong.png" /></span>
                                    </span></td>
                                  </tr>
                                  <tr>
                                    <td height="15"></td>
                                  </tr>
                                  <tr>
                                    <td width="100" align="left" valign="top"><strong>Comments: </strong></td>
                                    <td><span id="sprytextarea1">
                                    <textarea name="comments" id="comments" cols="40" rows="6"><?php echo $_POST['comments']; ?></textarea>
                                    <div style="position:relative;"><img src="images/ok.png" title="Valid" alt="Valid" class="validMsg validTextArea" border="0"/>
                                    <span class="textareaRequiredMsg" style="margin-left: 370px; margin-top: -20px; position:absolute;"><img src="images/wrong.png" /></span></div>
                                    </span>
                                    </td>
                                  </tr>
                                  <tr>
                                    <td height="15"></td>
                                  </tr>
                                  <tr>
                                    <td colspan="2" align="center" valign="middle" height="45px"><input type="submit" id="Submit" name="Submit" value="Submit" width="125px"></td>
                                  <tr>
                                  <tr>
                                    <td height="15"></td>
                                  </tr>
                                </table>
                                </form>
                                <?php }
                                    if (!isset($_POST['email']) || $_SERVER['REQUEST_METHOD'] != "POST") { 
                                        showMailForm(); 	
                                    } else {
                                        include("scripts/mail_options.php");
                                        if ($evil != 1) {
                                            $recipient = "jenano122@live.com";
                                            $subject = "Cozy Lil' Cottage Form Mail";
                                            
                                            $message = "You've received an e-mail through your website mail contact form: \n";
                                            $message .= "Name: {$_POST['name']} \n";
                                            $message .= "E-mail or Phone: {$_POST['email']} \n";
                                            $message .= "Comments: {$_POST['comments']} \n";
                                            
                                            $headers = "From: {$_POST['name']} <{$_POST['email']}> \n";
                                            $headers .= "Reply-To: <{$_POST['email']}>";
                                            
                                            if (mail($recipient,$subject,$message,$headers)) {
                                                echo "<p align='center'>Your mail was successfully sent to Cozy Lil' Cottage.<br>Thank you for your time.</p>\n"; 
                                            } else {
                                                echo "<p align='center' class='style1'>Sorry, there was an error and your mail was not sent.<br>Please email us at <a href='mailto:jen@cozylilcottage.com'>jen@cozylilcottage.com</a>.</p>\n";
                                                showMailForm();
                                                return;
                                            }
                                        }
                                    }
                                ?>
                                <script type="text/javascript">
                                var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "none", {validateOn:["change"]});
                                var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "none", {validateOn:["change"]});
                                var sprytextarea1 = new Spry.Widget.ValidationTextarea("sprytextarea1", {validateOn:["change"]});
                                </script>
                            </td>
                          </tr>
                        </table>
                    </td>
                  </tr>
                </table>
            </td>
          </tr>
        </table>
    </td>
  </tr>
</table>
</body>
</html>
