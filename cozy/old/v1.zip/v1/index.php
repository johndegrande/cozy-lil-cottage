<?php include("scripts/dbstuff.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="Hello, my name is Jen and I am the owner/director of Cozy Lil' Cottage! Children are my business. I have done in-home licensed childcare for 15 years and was an assistant director for 2 1/2 years. It has been my dream to have my own childcare facility. We opened November 10th, 2010.">
<meta name="keywords" content="day, care, daycare, cozy, lil, cottage, little, papillion, ne, nebraska, kids, infants, baby, toddler">
<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW, ARCHIVE" />
<link rel="icon" href="images/favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="stylesheet" href="scripts/main.css" type="text/css" media="all" />
<link rel="stylesheet" href="scripts/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
<link rel="stylesheet" href="scripts/nivo-slider/themes/default/default.css" type="text/css" media="screen" />
<link rel="stylesheet" href="scripts/nivo-slider/nivo-slider.css" type="text/css" media="screen" />
<script type="text/javascript" src="scripts/jquery-1.6.4.min.js"></script>
<script src="scripts/nivo-slider/jquery.nivo.slider.pack.js" type="text/javascript"></script>
<script type="text/JavaScript" src="scripts/picphun.js"></script>
<script type="text/javascript" src="scripts/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<script src="scripts/jquery.Scroller-1.0.min.js" type="text/javascript"></script>
<script type="text/javascript"> 
	$(document).ready(function() {
	/* Apply fancybox to multiple items */
	$("a.group").fancybox({
		'transitionIn'	:	'elastic',
		'transitionOut'	:	'elastic',
		'speedIn'		:	600, 
		'speedOut'		:	200, 
		'titlePosition' : 'inside',
		'overlayColor'	:	'#000'
	});
	
	$("a.contact_window").fancybox({
		'width'				: 645,
		'height'			: 485,
		'padding'			: 0,
		'scrolling'			: 'no',
        'autoScale'     	: false,
        'transitionIn'		: 'none',
		'transitionOut'		: 'none',
		'type'				: 'iframe',
		'overlayColor'		: '#000'
	});
	
	//create scroller for each element with "horizontal_scroller" class...
            $('.horizontal_scroller').SetScroller({	velocity: 	 90,
                                                    direction: 	 'horizontal',
                                                    startfrom: 	 'right',
                                                    loop:		 'infinite',
                                                    movetype: 	 'linear',
                                                    onmouseover: 'play',
                                                    onmouseout:  'play',
                                                    onstartup: 	 'play',
                                                    cursor: 	 'pointer'
                                                });
});
</script>
<script type="text/javascript">
$(window).load(function() {
    $('#slider').nivoSlider({
		effect: 'fade', // Specify sets like: 'fold,fade,sliceDown'
        animSpeed: 250, // Slide transition speed
        pauseTime: 3000, // How long each slide will show
        pauseOnHover: true, // Stop animation while hovering
        controlNav: false // Use thumbnails for Control Nav
    });
});
</script>
<title>Cozy Lil' Cottage, Papillion, NE</title>
</head>
<body onload="MM_preloadImages('images/hdr_email_ovr.png','images/hdr_add_ovr.png')">
<table width="100%" height="229px" border="0" cellspacing="0" cellpadding="0" align="center" style="background: url(images/bg.jpg) top center no-repeat;">
	<tr>
    	<td align="center" height="229px">
        	<table width="990px" height="229px" border="0" cellspacing="0" cellpadding="0" align="center">
        	  <tr>
                <td width="50%" align="center" valign="middle">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="center"><img src="images/hdr_logo.png" /></td>
                      </tr>
                      <tr>
                        <td height="85px" align="center" valign="middle">
                            <table width="468px" height="42px" border="0" cellspacing="0" cellpadding="0" style="background:url(images/rug_bg.png) center;">
                              <tr>
                                <td width="460px" height="34px" align="center" valign="middle">
                                	<div class="horizontal_scroller">
                                        <div class="scrollingtext">
                                            <?php
                                                $sql = "SELECT bulletin FROM ticker WHERE bulletin != '' ORDER BY id";
                                                $result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
                                                if (mysql_num_rows($result) == 0) {
                                                    echo "THANKS FOR VISITING COZY LIL' COTTAGE";
                                                } else {
                                                    $bull_cnt = 0;
                                                    while($row = mysql_fetch_assoc($result)) {
                                                        extract($row);
                                                        if ($bull_cnt == 0) {
                                                            echo strtoupper(str_replace('\\', '', $bulletin));
                                                            $bull_cnt = 1;
                                                        } else {
                                                            echo " | " . strtoupper(str_replace('\\', '', $bulletin));
                                                        }
                                                    }
                                                }
                                            ?>
                                        </div>
                                    </div>
                                </td>
                                <td width="8px"></td>
                              </tr>
                              <tr><td colspan="2" height="8px"></td></tr>
                            </table>
                        </td>
                      </tr>
                    </table>
                </td>
                <td width="48%" valign="top" align="center">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="header">
                      <tr><td height="5px"></td></tr>
                      <tr>
                        <td align="right">
                        	Jen Cervantes, Director<br />
                            <a href="contact.php" class="contact_window">jen@cozylilcottage.com</a><br />
                            <a href="https://maps.google.com/maps?q=Cozy+Lil'+Cottage+Childcare,+South+Washington+Street,+Papillion,+NE&hl=en&sll=41.152229,-96.042685&cid=5728394987231362530&hq=Cozy+Lil'+Cottage+Childcare,+South+Washington+Street,+Papillion,+NE&t=m&z=17&iwloc=A" target="_blank">517 S Washington St.<br />Papillion, NE 68046</a><br />
                            <table border="0" cellspacing="0" cellpadding="0"><tr><td align="right" valign="middle">(402)884-3888 • </td><td width="10px"></td><td align="right" valign="middle"><a href="http://www.facebook.com/pages/Cozy-Lil-Cottage-Child-Care-Inc/171221812982779" target="_blank"><img src="images/facebook_up.png" alt="Facebook" width="27" height="27" border="0" /></a></td></tr></table>
                            6:30<span class="ampm">AM</span> - 6:00<span class="ampm">PM</span> M-F
                        </td>
                      </tr>
                    </table>
                </td>
                <td width="2%"></td>
              </tr>
            </table>
        </td>
    </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5" align="center" style="background: url(images/bg.png) top center no-repeat;">
  <tr>
    <td align="center"><img src="images/thanks.png" /></td>
  </tr>
  <tr>
  	<td align="center">
    	<?php
			$sql = "SELECT * FROM feature_images ORDER BY id";
			$result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
			while($row = mysql_fetch_assoc($result)) {
				extract($row);
				$images[$id]['img'] = $img;
				$images[$id]['caption'] = stripslashes($caption);
			}
		?>
    	<table width="990px" border="0" cellspacing="0" cellpadding="5">
          <tr>
            <td width="230px">
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td>
                    	<table width="100%" height="189px" border="0" cellspacing="0" cellpadding="0" style="background: url(images/thumb_frame_red.png) center no-repeat;">
                          <tr>
                            <td width="245px" height="189px" align="center" valign="middle"><a href="images/uploads/<?php echo $images[1]['img']; ?>" class="group" rel="tour" caption="<?php echo $images[1]['caption']; ?>"><img src="images/uploads/thumb/<?php echo $images[1]['img']; ?>" border="0" width="166px" height="123px" /></a></td>
                          </tr>
                        </table>
                    </td>
                  </tr>
                  <tr><td height="5px"></td></tr>
                  <tr>
                    <td>
                    	<table width="100%" height="189px" border="0" cellspacing="0" cellpadding="0" style="background: url(images/thumb_frame_blu.png) center no-repeat;">
                          <tr>
                            <td width="245px" height="189px" align="center" valign="middle"><a href="images/uploads/<?php echo $images[2]['img']; ?>" class="group" rel="tour" caption="<?php echo $images[2]['caption']; ?>"><img src="images/uploads/thumb/<?php echo $images[2]['img']; ?>" border="0" width="166px" height="123px" /></a></td>
                          </tr>
                        </table>
                    </td>
                  </tr>
                </table>
            </td>
            <td align="center" valign="middle" width="507px" style="background: url(images/paper_bg_top.png) top center no-repeat;">
            	<table width="450px" border="0" cellspacing="0" cellpadding="0" align="center">
                  <tr>
                    <td align="left">
                        Hello, my name is Jen and I am the owner/director of Cozy Lil' Cottage! Children are my business. I have done in-home licensed childcare for 15 years and was an assistant director for 2 1/2 years. It has been my dream to have my own childcare facility. We opened November 10th, 2010. 
                        <ul>
                            <li>Ages: 6 weeks to 5 years</li>
                            <li>Very Reasonable Rates</li>
                            <li>Exceptional Care</li>
                            <li>Smaller atmosphere for more one-on-one interaction!</li>
                            <li>Exceptional preschool curriculum including Spanish and Sign Language</li>
                            <li>"Songbirds, Music and Movement" Music Class each week (the children love it!)</li>
                            <li>We offer a school-age program for the summer</li>
                        </ul>
                    </td>
                  </tr>
                </table>
            </td>
            <td width="229px">
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td>
                    	<table width="100%" height="189px" border="0" cellspacing="0" cellpadding="0" style="background: url(images/thumb_frame_yel.png) center no-repeat;">
                          <tr>
                            <td width="245px" height="189px" align="center" valign="middle"><a href="images/uploads/<?php echo $images[3]['img']; ?>" class="group" rel="tour" caption="<?php echo $images[3]['caption']; ?>"><img src="images/uploads/thumb/<?php echo $images[3]['img']; ?>" border="0" width="167px" height="123px" /></a></td>
                          </tr>
                        </table>
                    </td>
                  </tr>
                  <tr><td height="5px"></td></tr>
                  <tr>
                    <td>
                    	<table width="100%" height="189px" border="0" cellspacing="0" cellpadding="0" style="background: url(images/thumb_frame_pur.png) center no-repeat;">
                          <tr>
                            <td width="245px" height="189px" align="center" valign="middle"><a href="images/uploads/<?php echo $images[4]['img']; ?>" class="group" rel="tour" caption="<?php echo $images[4]['caption']; ?>"><img src="images/uploads/thumb/<?php echo $images[4]['img']; ?>" border="0" width="167px" height="123px" /></a></td>
                          </tr>
                        </table>
                    </td>
                  </tr>
                </table>
            </td>
          </tr>
          <tr>
          	<td align="center" colspan="3">
                <table width="990px" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="230px">
                        <table width="100%" height="189px" border="0" cellspacing="0" cellpadding="0" style="background: url(images/thumb_frame_pur.png) center no-repeat;">
                          <tr>
                            <td width="245px" height="189px" align="center" valign="middle"><a href="images/uploads/<?php echo $images[5]['img']; ?>" class="group" rel="tour" caption="<?php echo $images[5]['caption']; ?>"><img src="images/uploads/thumb/<?php echo $images[5]['img']; ?>" border="0" width="166px" height="123px" /></a></td>
                          </tr>
                        </table>
                    </td>
                    <td width="23px"></td>
                    <td width="230px">
                        <table width="100%" height="189px" border="0" cellspacing="0" cellpadding="0" style="background: url(images/thumb_frame_yel.png) center no-repeat;">
                          <tr>
                            <td width="245px" height="189px" align="center" valign="middle"><a href="images/uploads/<?php echo $images[6]['img']; ?>" class="group" rel="tour" caption="<?php echo $images[6]['caption']; ?>"><img src="images/uploads/thumb/<?php echo $images[6]['img']; ?>" border="0" width="166px" height="123px" /></a></td>
                          </tr>
                        </table>
                    </td>
                    <td width="24px"></td>
                    <td width="230px">
                        <table width="100%" height="189px" border="0" cellspacing="0" cellpadding="0" style="background: url(images/thumb_frame_red.png) center no-repeat;">
                          <tr>
                            <td width="245px" height="189px" align="center" valign="middle"><a href="images/uploads/<?php echo $images[7]['img']; ?>" class="group" rel="tour" caption="<?php echo $images[7]['caption']; ?>"><img src="images/uploads/thumb/<?php echo $images[7]['img']; ?>" border="0" width="166px" height="123px" /></a></td>
                          </tr>
                        </table>
                    </td>
                    <td width="23px"></td>
                    <td width="230px">
                        <table width="100%" height="189px" border="0" cellspacing="0" cellpadding="0" style="background: url(images/thumb_frame_blu.png) center no-repeat;">
                          <tr>
                            <td width="245px" height="189px" align="center" valign="middle"><a href="images/uploads/<?php echo $images[8]['img']; ?>" class="group" rel="tour" caption="<?php echo $images[8]['caption']; ?>"><img src="images/uploads/thumb/<?php echo $images[8]['img']; ?>" border="0" width="166px" height="123px" /></a></td>
                          </tr>
                        </table>
                    </td>
                  </tr>
                </table>
            </td>
          </tr>
        </table>
    </td>
  </tr>
  <tr>
    <td align="center">
        <table width="990px" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="507px" height="395px" align="center" valign="middle" style="background: url(images/paper_bg_top.png) top center no-repeat;">
            	<table width="450px" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="left">
                        <p>We would love for your family to be a part of ours.  We designed this center to be home-like and with a smaller amount of children.  This allows the staff to have more one-on-one interaction with your child. We will have consistent room movement. They will be able to go to the library, music, play room, etc.  We will also be teaching cooking and gardening classes.</p>
                                        <p>A really great benefit to our program is "Parents Night Out" which will be held once a month on a Friday night. For a fee you can drop off your child and enjoy a night to yourselves. Fun activities will be planned for the children. Snacks will be provided.</p>
                                        <p>Contact Jen to take a tour today! You can reach us by phone at (402)884-3888, by e-mail at <a href="mailto:jen@cozylilcottage.com">jen@cozylilcottage.com</a> or by using our  <a href="contact.php" class="contact_window">Contact Form</a>!</p>
                    </td>
                  </tr>
                </table>
            </td>
            <td width="483px" align="center" valign="middle">
            	<table width="482px" border="0" cellspacing="0" cellpadding="0" style="background: url(images/slide_frame_red.png) top center no-repeat;">
                  <tr>
                    <td width="482px" height="335px" align="center" valign="middle">
                    	<table width="322px" border="0" cellspacing="0" cellpadding="0">
                          <tr><td height="6px"></td></tr>
                          <tr>
                            <td height="214px">
                            	<div class="slider-wrapper theme-default">
                                    <div id="slider">
                                    	<?php
										$sql = "SELECT * FROM slideshow WHERE img != '' ORDER BY id";
                                        $result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
										while($row = mysql_fetch_assoc($result)) {
											extract($row); ?>
                                            <a href="images/uploads/<?php echo $img; ?>" class="group" rel="slide" caption="<?php if ($event != '') { echo $event . " - "; } echo $description; ?>"><img src="images/uploads/slide/<?php echo $img; ?>" border="0" title="<?php if ($event != '') { echo stripslashes($event) . " - "; } echo stripslashes($description); ?>" /></a>
                                        <?php } ?>
                                    </div>
                                </div>
                            </td>
                          </tr>
                        </table>
                    </td>
                </table>
            </td>
          </tr>
        </table>
    </td>
  </tr>
  <tr>
  	<td align="center" valign="middle" height="180px" style="background: url(images/paper_bg_btm.png) center no-repeat;">
    	<table width="675px" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center">
                <p>Be sure to check out our <a href="http://www.facebook.com/pages/Cozy-Lil-Cottage-Child-Care-Inc/171221812982779" target="_blank">Facebook</a> page for more photos (and be sure to like us)!</p>
                <p>**Mention viewing this website and receive 1st weeks tuition 1/2 off**</p>
                <p>Keep checking back for updates and specials!</p>
            </td>
          </tr>
        </table>
    </td>
  </tr>
</table>
</body>
</html>