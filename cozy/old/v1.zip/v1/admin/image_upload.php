<?php include("../scripts/dbstuff.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cozy Lil' Cottage Admin - Image Upload</title>
</head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr><td align="center"><h2>IMAGE UPLOAD</h2></td></tr>
  <tr>
    <td align="center">
        To use a picture on the page, it must first be uploaded to the site. The script will automatically format itself to the size(s) needed so don't worry about uploading multiple copies of the same photo. NOTE: Leave the Save As field blank if you do not want to change the name of the file.
        <form enctype="multipart/form-data" action="image_upload.php" method="POST">
        <table width="90%" border="0" cellspacing="5" cellpadding="5">
          <tr>
            <td align="center">
<?php
if(!isset($_POST['Upload'])) { //Checks to see if the form has been posted
//
}
else
{
if($_FILES['pix']['size'] > "10000000")	
{
    echo "<b>File did not successfully upload. Check the file size.</b>\n";
}
if(!preg_match("/image/", $_FILES['pix']['type']))
{
    echo "<b>File is not a picture or the file is over 1MB. Check the file size and make sure you're trying to upload an image (.jpg, .png or .gif). Please try another file.</b>\n";
}
else
{
	if ($_POST['name'] != '') {
		$new_name = $_POST['name'] . ".jpg";
	} else {
		$new_name = $_FILES['pix']['name'];
	}
	
	$width = 1024;		//maximum width and height for the picture and thumbnail
	$width_thumb = 220;
	$height_thumb_new = 165;
	$width_slide = 322;
    $height_slide_new = 214;
	
	$destination="../images/uploads/".$new_name;		//path for the uploaded image
    $dest_thumb="../images/uploads/thumb/".$new_name;		//path for the thumbnail
    $dest_slide="../images/uploads/slide/".$new_name;		//path for the slideshow thumbnail
	
	$temp_file = $_FILES['pix']['tmp_name'];
	move_uploaded_file($temp_file, $destination);	//moves the uploaded file to image directory
	echo "<p style='font-weight: bold'>The file has been successfully uploaded: {$_FILES['pix']['name']} ({$_FILES['pix']['size']})</p>\n";
	
	list($width_orig, $height_orig) = getimagesize($destination);	//grabs dimensions from uploaded file
	$ratio_orig = $width_orig/$height_orig;
	$height_thumb = $width_thumb/$ratio_orig;
	$height_slide = $width_slide/$ratio_orig;
	if ($width_orig > $width) {
		$height = $width/$ratio_orig;
		$image_p = imagecreatetruecolor($width, $height);
		$image = imagecreatefromjpeg($destination);
		imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);	//resamples the uploaded image with new dimensions
		imagejpeg($image_p, $destination, 80);	//stores new photo in original directory
	}
	
	list($width_orig, $height_orig) = getimagesize($destination);
	
	//thumb
	$image_p = imagecreatetruecolor($width_thumb, $height_thumb_new);
	$image = imagecreatefromjpeg($destination);
	if ($height_thumb > $width_thumb) {
		$difference = ($height_thumb - $height_thumb_new);
		$y_offset = ($difference / 2);
		imagecopyresampled($image_p, $image, 0, 0, 0, $y_offset, $width_thumb, $height_thumb, $width_orig, $height_orig);
	} else {
		imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width_thumb, $height_thumb_new, $width_orig, $height_orig);	//resamples the uploaded image with new dimensions
	}
	imagejpeg($image_p, $dest_thumb, 80);	//stores new photo in original directory
	
	//thumb
	$image_p = imagecreatetruecolor($width_slide, $height_slide_new);
	$image = imagecreatefromjpeg($destination);
	if ($height_slide > $width_slide) {
		$difference = ($height_slide - $height_slide_new);
		$y_offset = ($difference / 2);
		imagecopyresampled($image_p, $image, 0, 0, 0, $y_offset, $width_slide, $height_slide, $width_orig, $height_orig);
	} else {
		imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width_slide, $height_slide_new, $width_orig, $height_orig);	//resamples the uploaded image with new dimensions
	}
	imagejpeg($image_p, $dest_slide, 80);	//stores new photo in original directory
	
	$sql = "SELECT * FROM image_names WHERE name = '$new_name'";
	$result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
	if (mysql_num_rows($result) == 0) {
		$sql = "INSERT INTO image_names (name) VALUES ('$new_name')";
		$result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
	}
}
}
?>
            </td>
          </tr>
          <tr>
            <td align="center"><input type="hidden" name="MAX_FILE_SIZE" value="10000000" />
            <input type="file" name="pix" size="60" /></td>
          </tr>
          <tr>
            <td align="center">Save As: <input type="text" name="name" size="50" /></td>
          </tr>
          <tr>
            <td align="center"><input type="submit" name="Upload" value="Upload Picture" /></td>
          </tr>
        </table>
        </form>
    </td>
  </tr>
</table>
</body>
</html>