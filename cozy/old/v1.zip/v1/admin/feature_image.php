<?php include("../scripts/dbstuff.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cozy Lil' Cottage Admin - Featured Images</title>
<style type="text/css">
<!--
html, body {
	background: #30AE0D;
	color: #FFFFFF;
}
img {
	border-color: #30AE0D;
}
.image_select {
	border-color: #FFFFFF;
}
.hand_pointer {
	cursor: pointer;
}
-->
</style>
</head>
<?php
	if ($_POST['feature_submit'] == "SAVE CHANGES") {
		for($i=1;$i<=8;$i++) {
			$text_post[$i] = mysql_real_escape_string($_POST['txt_' . $i]);
			$cap_post[$i] = mysql_real_escape_string($_POST['cap_' . $i]);
			$sql = "UPDATE feature_images SET img = '$text_post[$i]', caption = '$cap_post[$i]' WHERE id = '$i'";
			$result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
		}
		echo "<b>FEATURED IMAGES HAVE BEEN UPDATED!</b>";
	}
?>
<script type="text/javascript">
	var img_box = '';
	var img_name = '';
	
	function img_select (img) {
		img_box = img;
		document.getElementById('img_'+img_box).style.borderColor = '#FF0000';
		for (i=1; i<=8; i++) {
			if (i != img_box) {
				img_border = 'img_'+i;
				document.getElementById(img_border).style.borderColor = '#30AE0D';
			}
		}
	}
	
	function give_me_a_name(img_box, img_name) {
		document.getElementById('img_'+img_box).src = 'http://www.cozylilcottage.com/images/uploads/thumb/'+img_name;
		document.getElementById('txt_'+img_box).value = img_name;
	}
</script>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr><td align="center"><h2>FEATURED IMAGES</h2></td></tr>
  <tr>
    <td align="center">
        To change a picture, first click on the picture you'd like to replace and then choose a new picture form the selection box.
        <?php
			$sql = "SELECT * FROM feature_images";
			$result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
			while($row = mysql_fetch_assoc($result)) {
				extract($row);
				$images[$id] = $img;
				$captions[$id] = $caption;
			}
		?>
        <form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
        <table width="990px" border="0" cellspacing="3" cellpadding="0">
          <tr>
            <td align="center">
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center"><img src="http://www.cozylilcottage.com/images/uploads/thumb/<?php echo $images[1]; ?>" id="img_1" onclick="img_select('1')" class="hand_pointer" border="2px" /></td>
                  </tr>
                  <tr>
                    <td align="center"><input type="text" id="txt_1" name="txt_1" size="20" onclick="img_select('1')" readonly="readonly" class="hand_pointer" value="<?php echo $images[1]; ?>" /></td>
                  </tr>
                  <tr>
                  	<td align="center">Caption: <input type="text" id="cap_1" name="cap_1" size="20" maxlength="256" onclick="img_select('1')" value="<?php echo $captions[1]; ?>" /></td>
                  </tr>
                </table>
            </td>
            <td colspan=2 rowspan=2 align="center">
            	<div style="width: 470px; height: 400px; overflow: auto; padding: 3px; background:#FFFFFF;">
                	<h3 style="color:#000000;">IMAGE SELECTION</h3>
					<?php
                        $sql = "SELECT * FROM image_names";
                        $result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
                        while($row = mysql_fetch_assoc($result)) {
                            extract($row);
                            echo "<img src='http://www.cozylilcottage.com/images/uploads/thumb/" . $name . "' onclick=\"give_me_a_name(img_box, '$name');\" border=1 class='hand_pointer image_select'>";
                        }
                    ?>
                </div>
            </td>
            <td>
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center"><img src="http://www.cozylilcottage.com/images/uploads/thumb/<?php echo $images[3]; ?>" id="img_3" onclick="img_select('3')" class="hand_pointer" border="2px" /></td>
                  </tr>
                  <tr>
                    <td align="center"><input type="text" id="txt_3" name="txt_3" size="20" onclick="img_select('3')" readonly="readonly" class="hand_pointer" value="<?php echo $images[3]; ?>" /></td>
                  </tr>
                  <tr>
                  	<td align="center">Caption: <input type="text" id="cap_3" name="cap_3" size="20" maxlength="256" onclick="img_select('3')" value="<?php echo $captions[3]; ?>" /></td>
                  </tr>
                </table>
            </td>
          </tr>
          <tr>
            <td>
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center"><img src="http://www.cozylilcottage.com/images/uploads/thumb/<?php echo $images[2]; ?>" id="img_2" onclick="img_select('2')" class="hand_pointer" border="2px" /></td>
                  </tr>
                  <tr>
                    <td align="center"><input type="text" id="txt_2" name="txt_2" size="20" onclick="img_select('2')" readonly="readonly" class="hand_pointer" value="<?php echo $images[2]; ?>" /></td>
                  </tr>
                  <tr>
                  	<td align="center">Caption: <input type="text" id="cap_2" name="cap_2" size="20" maxlength="256" onclick="img_select('2')" value="<?php echo $captions[2]; ?>" /></td>
                  </tr>
                </table>
            </td>
            <td>
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center"><img src="http://www.cozylilcottage.com/images/uploads/thumb/<?php echo $images[4]; ?>" id="img_4" onclick="img_select('4')" class="hand_pointer" border="2px" /></td>
                  </tr>
                  <tr>
                    <td align="center"><input type="text" id="txt_4" name="txt_4" size="20" onclick="img_select('4')" readonly="readonly" class="hand_pointer" value="<?php echo $images[4]; ?>" /></td>
                  </tr>
                  <tr>
                  	<td align="center">Caption: <input type="text" id="cap_4" name="cap_4" size="20" maxlength="256" onclick="img_select('4')" value="<?php echo $captions[4]; ?>" /></td>
                  </tr>
                </table>
            </td>
          </tr>
          <tr>
            <td>
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center"><img src="http://www.cozylilcottage.com/images/uploads/thumb/<?php echo $images[5]; ?>" id="img_5" onclick="img_select('5')" class="hand_pointer" border="2px" /></td>
                  </tr>
                  <tr>
                    <td align="center"><input type="text" id="txt_5" name="txt_5" size="20" onclick="img_select('5')" readonly="readonly" class="hand_pointer" value="<?php echo $images[5]; ?>" /></td>
                  </tr>
                  <tr>
                  	<td align="center">Caption: <input type="text" id="cap_5" name="cap_5" size="20" maxlength="256" onclick="img_select('5')" value="<?php echo $captions[5]; ?>" /></td>
                  </tr>
                </table>
            </td>
            <td>
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center"><img src="http://www.cozylilcottage.com/images/uploads/thumb/<?php echo $images[6]; ?>" id="img_6" onclick="img_select('6')" class="hand_pointer" border="2px" /></td>
                  </tr>
                  <tr>
                    <td align="center"><input type="text" id="txt_6" name="txt_6" size="20" onclick="img_select('6')" readonly="readonly" class="hand_pointer" value="<?php echo $images[6]; ?>" /></td>
                  </tr>
                  <tr>
                  	<td align="center">Caption: <input type="text" id="cap_6" name="cap_6" size="20" maxlength="256" onclick="img_select('6')" value="<?php echo $captions[6]; ?>" /></td>
                  </tr>
                </table>
            </td>
            <td>
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center"><img src="http://www.cozylilcottage.com/images/uploads/thumb/<?php echo $images[7]; ?>" id="img_7" onclick="img_select('7')" class="hand_pointer" border="2px" /></td>
                  </tr>
                  <tr>
                    <td align="center"><input type="text" id="txt_7" name="txt_7" size="20" onclick="img_select('7')" readonly="readonly" class="hand_pointer" value="<?php echo $images[7]; ?>" /></td>
                  </tr>
                  <tr>
                  	<td align="center">Caption: <input type="text" id="cap_7" name="cap_7" size="20" maxlength="256" onclick="img_select('7')" value="<?php echo $captions[7]; ?>" /></td>
                  </tr>
                </table>
            </td>
            <td>
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center"><img src="http://www.cozylilcottage.com/images/uploads/thumb/<?php echo $images[8]; ?>" id="img_8" onclick="img_select('8')" class="hand_pointer" border="2px" /></td>
                  </tr>
                  <tr>
                    <td align="center"><input type="text" id="txt_8" name="txt_8" size="20" onclick="img_select('8')" readonly="readonly" class="hand_pointer" value="<?php echo $images[8]; ?>" /></td>
                  </tr>
                  <tr>
                  	<td align="center">Caption: <input type="text" id="cap_8" name="cap_8" size="20" maxlength="256" onclick="img_select('8')" value="<?php echo $captions[8]; ?>" /></td>
                  </tr>
                </table>
            </td>
          </tr>
        </table>
        <input name="feature_submit" type="submit" value="SAVE CHANGES" />
		</form>
    </td>
  </tr>
</table>
</body>
</html>