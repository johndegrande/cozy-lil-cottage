<?php include("../scripts/dbstuff.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cozy Lil' Cottage Admin - Bulletins</title>
</head>
<?php
	if ($_POST['bulletin_submit'] == "SAVE CHANGES") {
		for($i=1;$i<=10;$i++) {
			$bull_post[$i] = mysql_real_escape_string($_POST['bulletin' . $i]);
			$sql = "UPDATE ticker SET bulletin = '$bull_post[$i]' WHERE id = '$i'";
			$result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
		}
		echo "<b>BULLETINS HAVE BEEN UPDATED!</b>";
	}
?>
<body>
<?php
	$sql = "SELECT * FROM ticker ORDER BY id";
	$result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
?>
<form enctype='multipart/form-data' action='bulletins.php' method='POST'>
<table border="0" cellspacing="3" cellpadding="0" align="center">
  <tr>
    <td colspan=2 align="center"><h2>BULLETINS</h2></td>
  </tr>
  <?php
  	while($row = mysql_fetch_assoc($result)) {
		extract($row); ?>
        <tr>
        	<td align="right"><?php echo $id . ": "; ?></td>
            <td align="left"><input name="bulletin<?php echo $id; ?>" type="text" value="<?php echo str_replace('\\', '', $bulletin) ?>" size="100" maxlength="2056" /></td>
        </tr>
  <?php } ?>
  <tr>
  	<td colspan=2 align="center"><input name="bulletin_submit" type="submit" value="SAVE CHANGES" /></td>
  </tr>
</table>
</form>
</body>
</html>
