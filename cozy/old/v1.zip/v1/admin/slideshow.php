<?php include("../scripts/dbstuff.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cozy Lil' Cottage Admin - Slideshow Setup</title>
<style type="text/css">
<!--
html, body {
	background: #30AE0D;
	color: #FFFFFF;
}
img {
	border-color: #30AE0D;
}
.image_select {
	border-color: #FFFFFF;
}
.hand_pointer {
	cursor: pointer;
}
-->
</style>
</head>
<?php
	if ($_POST['slide_submit'] == "SAVE CHANGES") {
		for($i=1;$i<=$_POST['slide_count'];$i++) {
			$text_post[$i] = mysql_real_escape_string($_POST['txt_' . $i]);
			$cap_post[$i] = mysql_real_escape_string($_POST['cap_' . $i]);
			$event_post[$i] = mysql_real_escape_string($_POST['event_' . $i]);
			$id_post[$i] = mysql_real_escape_string($_POST['order_' . $i]);
			$sql = "UPDATE slideshow SET img = '$text_post[$i]', event = '$event_post[$i]', description = '$cap_post[$i]' WHERE id = '$id_post[$i]'";
			$result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
		}
		echo "<b>SLIDESHOW IMAGES HAVE BEEN UPDATED!</b>";
	}
?>
<script type="text/javascript">
	var img_box = '';
	var img_name = '';
	var old_number = '';
	
	function img_select (img) {
		img_box = img;
		document.getElementById('img_'+img_box).style.borderColor = '#FF0000';
		for (i=1; i<=8; i++) {
			if (i != img_box) {
				img_border = 'img_'+i;
				document.getElementById(img_border).style.borderColor = '#30AE0D';
			}
		}
	}
	
	function give_me_a_name(img_box, img_name) {
		document.getElementById('img_'+img_box).src = 'http://www.cozylilcottage.com/images/uploads/slide/'+img_name;
		document.getElementById('txt_'+img_box).value = img_name;
	}
	
	function set_old_number(src_box) {
		old_number = document.getElementById(src_box).value;
	}
	
	function re_number(src_box, row_cnt) {
		var new_number = document.getElementById(src_box).value;
		for (i=1; i<=row_cnt; i++) {
			if (old_number > new_number) {
				if (document.getElementById('order_'+i).selectedIndex >= new_number -1 && document.getElementById('order_'+i).selectedIndex <= old_number-1) {
					if (src_box != 'order_'+i) {
						document.getElementById('order_'+i).selectedIndex = document.getElementById('order_'+i).selectedIndex + 1;
					}
				}
			} else if (old_number < new_number) {
				if (document.getElementById('order_'+i).selectedIndex <= new_number -1 && document.getElementById('order_'+i).selectedIndex >= old_number-1) {
					if (src_box != 'order_'+i) {
						document.getElementById('order_'+i).selectedIndex = document.getElementById('order_'+i).selectedIndex - 1;
					}
				}
			}
		}
	}
	
	function clear_fields(src_box) {
		document.getElementById('img_'+src_box).src = 'http://www.cozylilcottage.com/images/uploads/slide/no_slide.png';
		document.getElementById('txt_'+src_box).value = '';
		document.getElementById('event_'+src_box).value = '';
		document.getElementById('cap_'+src_box).value = '';
	}
</script>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr><td align="center"><h2>SLIDESHOW SETUP</h2></td></tr>
  <tr>
    <td align="center">
        To change a picture, first click on the picture you'd like to replace and then choose a new picture from the selection box.
      <?php
			$sql = "SELECT * FROM slideshow ORDER BY id";
			$result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
			$row_cnt = mysql_num_rows($result);
			while($row = mysql_fetch_assoc($result)) {
				extract($row);
				$images[$id] = $img;
				$events[$id] = stripslashes($event);
				$captions[$id] = stripslashes($description);
			}
		?>
        <form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
        <input type="hidden" name="slide_count" value="<?php echo $row_cnt; ?>" />
        <table width="990px" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center" width="50%">
            	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                <?php
					for($i=1;$i<=$row_cnt;$i++) { ?>
                  <tr>
                    <td align="center">
                    	<table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td align="center"><img src="http://www.cozylilcottage.com/images/uploads/slide/<?php if ($images[$i] == '') { echo "no_slide.png"; } else { echo $images[$i]; } ?>" id="img_<?php echo $i; ?>" onclick="img_select('<?php echo $i; ?>')" class="hand_pointer" border="2px" /></td>
                          </tr>
                          <tr>
                            <td align="center">Order: <select id="order_<?php echo $i; ?>" name="order_<?php echo $i; ?>" onfocus="set_old_number('order_<?php echo $i; ?>');" onchange="re_number('order_<?php echo $i; ?>', '<?php echo $row_cnt; ?>');"><?php for ($j=1;$j<=$row_cnt;$j++) { echo "<option value='$j'"; if ($j == $i) { echo " SELECTED"; } echo ">$j</option>"; } ?></select>Image: <input type="text" id="txt_<?php echo $i; ?>" name="txt_<?php echo $i; ?>" size="20" onclick="img_select('<?php echo $i; ?>')" readonly="readonly" class="hand_pointer" value="<?php echo $images[$i]; ?>" /></td>
                          </tr>
                          <tr>
                            <td align="center">Event: <input type="text" id="event_<?php echo $i; ?>" name="event_<?php echo $i; ?>" size="30" maxlength="256" onclick="img_select('<?php echo $i; ?>')" value="<?php echo $events[$i]; ?>" /></td>
                          </tr>
                          <tr>
                            <td align="center">Caption: <input type="text" id="cap_<?php echo $i; ?>" name="cap_<?php echo $i; ?>" size="30" maxlength="256" onclick="img_select('<?php echo $i; ?>')" value="<?php echo $captions[$i]; ?>" /></td>
                          </tr>
                          <tr>
                            <td align="center"><input type="button" onclick="clear_fields('<?php echo $i; ?>');" value="CLEAR FIELDS" /></td>
                          </tr>
                        </table>
                    </td>
                  </tr>
				<?php } ?>
                </table>
            </td>
            <td valign="top" width="50%">
              <div style="width: 470px; height: 400px; overflow: auto; padding: 3px; background:#FFFFFF; position: fixed;">
                <h3 style="color:#000000;">IMAGE SELECTION</h3>
                    <?php
                        $sql = "SELECT * FROM image_names";
                        $result = mysql_query($sql) or die ("Couldn't execute query." . mysql_error());
                        while($row = mysql_fetch_assoc($result)) {
                            extract($row);
                            echo "<img src='http://www.cozylilcottage.com/images/uploads/thumb/" . $name . "' onclick=\"give_me_a_name(img_box, '$name');\" border=1 class='hand_pointer image_select'>";
                        }
                    ?>
              </div>
            </td>
          </tr>
        </table>
        <input name="slide_submit" type="submit" value="SAVE CHANGES" />
		</form>
    </td>
  </tr>
</table>
</body>
</html>